"use strict"

const RESERVATIONS_AMOUNT = 10
const rooms = ['208', '303', '108']
const teachers = ['Ушаков Д.М.', 'Лянгузов Ф.А.', 'Мирзаянов М.Р.']
const purposes = ['занятие 1', 'занятие 2', 'занятие 3']
const subjects = ['программирование', 'математика']

function get(url, args, callback) {
    // Представим, что эта функция делает запрос на сервер

    // url - интуитивно понятно, что это такое - адрес, по которому хотим сделать запрос.
    // args - аргументы запроса.
    // callback - функция, которая будет вызвана, когда придет ответ от сервера.
    // В неё передадим ответ сервера.
    console.log(url, args)
    if (url === "/get_reservations") {
        const res = Array.from({length: RESERVATIONS_AMOUNT}, generate_reservation)
        callback(res)
    } else if (url === "/get_rooms") {
        const res = rooms.map((el) => ({
            number: el,
            teacher: teachers.random(),
            info: ['Компьютерный класс', 'Ни чем не выделяющийся кабинет'],
        }))
        callback(res)
    }
}

function post(url, args, callback) {
    console.log(url, args)
    callback()
}

// Что происходит дальше понимать не обязательно, просто генерация тестовых данных

function generate_datetime() {
    let gen_number = (max) => (Math.floor(Math.random() * max) + 1).toString().padStart(2, '0')
    let date = gen_number(31) + '.' +
        gen_number(12) + '.2023 '
    return [date + '12:00', date + '13:00']
}

Array.prototype.random = function () {
    return this[Math.floor((Math.random() * this.length))];
}

function generate_reservation() {
    let datetime = generate_datetime()
    return {
        room: rooms.random(),
        teacher: teachers.random(),
        purpose: purposes.random(),
        startTime: datetime[0],
        endTime: datetime[1],
        subject: subjects.random()
    }
}
